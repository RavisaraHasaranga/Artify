document.getElementById("anchorbutton1").onclick = function () {
   location.href = "#16thcentury";
};

document.getElementById("anchorbutton2").onclick = function () {
   location.href = "#17thcentury";
};

document.getElementById("anchorbutton3").onclick = function () {
   location.href = "#18thcentury";
};
document.getElementById("anchorbutton4").onclick = function () {
   location.href = "#19thcentury";
};

var toTopButton = document.getElementById("top-btn");

window.onscroll = function () { showButton() };