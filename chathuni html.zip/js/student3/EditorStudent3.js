document.getElementById('back-btn').addEventListener('click',()=>{
    window.history.back();
})
