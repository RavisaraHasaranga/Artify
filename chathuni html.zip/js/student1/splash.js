document.addEventListener("DOMContentLoaded", function () {
  const splashScreen = document.getElementById("splash-screen");
  setTimeout(() => {
    splashScreen.style.display = "none";
  }, 5000);
});
